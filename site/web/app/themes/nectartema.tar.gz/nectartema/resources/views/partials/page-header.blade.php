<div
    class="mt-8 page-header">
    <h1 class="bg-yellow-400 {{ !is_woocommerce() && !is_cart() && !is_checkout() ? ' container' : '' }}">{!! $title !!}</h1>
</div>
