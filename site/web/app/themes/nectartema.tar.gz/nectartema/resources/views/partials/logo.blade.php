<a class="brand block max-w-[302px] w-full" href="{{ home_url('/') }}">
  <div class="aspect-[302/84] w-full">
    <img width="302" height="84" class="w-full h-full object-contain block hover:scale-105 transition duration-300 ease-in-out" id="logo" alt="Logo da Néctar da Amazônia" src="{{ Vite::asset('resources/images/logonectarnovo.webp') }}" />
  </div>
</a>
